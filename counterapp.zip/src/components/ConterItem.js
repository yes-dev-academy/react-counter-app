import React, { Component } from "react";

export class ConterItem extends Component {
  render() {
    return (
      <div className="row">
        <div className="col">
          <span class="badge badge-warning">Zero</span>
        </div>
        <div className="col">
          <button className="btn btn-secondary">
            <i className="fa fa-plus-circle" aria-hidden="true"></i>
          </button>
        </div>
        <div className="col">
          <button class="btn btn-info m-2">
            <i class="fa fa-minus-circle" aria-hidden="true"></i>
          </button>
        </div>
        <div className="col">
          <button class="btn btn-danger">
            <i class="fa fa-trash-o" aria-hidden="true"></i>
          </button>
        </div>
      </div>
    );
  }
}

export default ConterItem;
