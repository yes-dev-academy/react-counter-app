import React, { Component } from "react";
import ConuterItem from "./ConterItem";

class Counters extends Component {
  render() {
    return (
      <div>
        <button className="btn peach-gradient btn-sm m-1">
          <i className="fas fa-sync" aria-hidden="true"></i>
        </button>
        <button className="btn blue-gradient btn-sm m-1">
          <i className="fa fa-recycle" aria-hidden="true"></i>
        </button>
      </div>
    );
  }
}

export default Counters;
