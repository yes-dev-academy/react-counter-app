import React, { Component } from 'react'
import Navbar from './components/layout/Navbar'
import Counters from './components/Counters'

export class App extends Component {
  state={
    counters:[
      {id:1,valu:0},
      {id:2,valu:0},
      {id:3,valu:0},
      {id:4,valu:0},
      {id:5,valu:0},
      {id:6,valu:0}
    ]
  }
  render() {
    return (
      <div>
      <Navbar totalCounter={this.state.counters.filter(counter=> counter.value>0).length}/>
      <Counters/>
        app
      </div>
    )
  }
}

export default App
